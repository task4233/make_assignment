#include <stdio.h>

int main()
{
  printf("This is 2nd file.");
  return 0;
}
